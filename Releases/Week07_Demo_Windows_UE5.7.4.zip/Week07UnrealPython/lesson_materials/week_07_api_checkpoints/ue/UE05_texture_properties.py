"""UE05: read properties of selected textures; skip other asset classes."""

# Section: setup
import unreal
assets = unreal.EditorUtilityLibrary.get_selected_assets()
textures = [asset for asset in assets
            if isinstance(asset, unreal.Texture2D)]
print("Textures:", len(textures), "skipped:", len(assets) - len(textures))

# Section: focus
for texture in textures:
    compression = texture.get_editor_property("compression_settings")
    srgb = texture.get_editor_property("srgb")
    print(texture.get_name(), compression, "sRGB:", srgb)
